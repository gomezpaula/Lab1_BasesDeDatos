<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    
    <body>
        <TABLE BORDER>
              <TR>
              <br>
              
                <TH>Negocio</TH>
		<TH>Inicio</TH>
		<TH>CC</TH>
                <TH>Cliente</TH>
                <TH>Fecha</TH>
                <TH>Letra</TH>
                <TH>Prefijo</TH>
                <TH>Numero</TH>
                <TH>TC</TH>
                <TH>Moneda</TH>
                <TH>Monto</TH>
                <TH>CodPR</TH>
                <TH>Prestador</TH>
                  <br>
	</TR>
      
    
</body>
        <?php
        //Configuracion de la conexion a base de datos
        $bd_host = "localhost";
        $bd_usuario = "root";
        $bd_password = "";
        $bd_base = "a";

        //$con = mysql_connect($bd_host, $bd_usuario, $bd_password);
        $mysqli = new mysqli('127.0.0.1', 'root', '', 'a');
        $mysqli->set_charset("utf8");

        //mysql_select_db($bd_base, $con);

//consulta todos los registros

        //$sql = mysql_query("SELECT * FROM empleados", $con);
        $res = $mysqli->query("SELECT * FROM info");
//consulta especifica de alguna caracteristica
       
 while($f = $res->fetch_object()){
     
   
    echo $f->negocio . ' <td/>'; 
    echo $f->inicio . ' <td/>'; 
    echo $f->cc . ' <td/>'.'<br>';
    echo $f->cliente . ' <td/>'.'<br>';
    echo $f->fecha . ' <td/>'.'<br>';
    echo $f->letra . ' <td/>'.'<br>';
    echo $f->prefijo . ' <td/>'.'<br>';
    echo $f->numero . ' <td/>'.'<br>';
    echo $f->tc . ' <td/>'.'<br>';
    echo $f->moneda . ' <td/>'.'<br>';
    echo $f->monto . ' <td/>'.'<br>';
    echo $f->codpr . ' <td/>'.'<br>';
    echo $f->prestador . ' <td/>'.'<br>';
    
     
   }


 
    