<!DOCTYPE html>
<html lang="es">
<head>
<title>Filtrar</title>
<link rel="stylesheet" type="text/css" href="resources/style.css">
</head>
<body>
	<nav>
		<ul>
			<li><a href="#">MENU</a></li>
			
		</ul>
	</nav>