<?php require("connection.php"); ?>


<?php 
	if(isset($_POST['filtro'])){
		switch($_POST['filtro']){
			case "todos":
				$sql = "select * from info;";
				break;
			case "negocio":
				$sql = "select negocio from info ;";
				break;
			case "cliente":
				$sql = "select cliente from info ;";
				break;
			case "monto":
				$sql = "select monto from info ;";
				break;
			case "prestador":
				$sql = "select prestador from info;";
				break;
		}
	}else{
		$sql = "select * from info;";
	}
?>

<?php include("templates/header.php"); ?>

<h1></h1>
<h3>Listado de UATP</h3>
<div id="filtros">
Filtrar información <form action="index.php" method="post"><select name="filtro"><option value="todos"></option><option value="negocio">Negocio</option><option value="cliente">Cliente</option><option value="monto">Monto</option><option value="prestador">Prestador</option></select> <button type="submit">Filtrar</button></form>
</div>
<div id="info">
    
	<?php 
        $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "a";
       $connection =mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
		$result = mysqli_query($connection,$sql);
		if(!$result )
		{
		 //	die('Ocurrio un error al obtener los valores de la base de datos: ' . mysqli_error());
		}
		echo "<center><table><th>Negocio</th><th>Inicio</th><th>Cc</th><th>Cliente</th><th>Fecha</th><th>Letra</th><th>Prefijo</th><th>Numero</th><th>Tc</th><th>Moneda</th><th>Monto</th><th>Codpre</th><th>Prestador</th>";

		while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
		{
		    echo "<tr><td>{$row['id']}</td> ".		    
                    "<td>{$row['negocio' ]} </td> ". 
                    "<td>{$row['inicio']} </td> ". 
                    "<td>{$row['cc']} </td> ".
                    "<td>{$row['cliente' ]} </td> ".
                    "<td>{$row['fecha' ]} </td> ".
                    "<td>{$row['letra' ]} </td> ".
                    "<td>{$row['prefijo' ]} </td> ".
                    "<td>{$row['numero' ]} </td> ".
                    "<td>{$row['tc' ]} </td> ".
                    "<td>{$row['moneda' ]} </td> ".
                    "<td>{$row['monto' ]} </td> ".
                    "<td>{$row['codpr' ]} </td> ".
                    "<td>{$row['prestador' ]} </td></tr>";
                }
		echo "</table></center>";
		//mysqli_close($connection);
	?>
</div>

<?php include("templates/footer.php"); ?>