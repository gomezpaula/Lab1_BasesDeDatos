<?php

function conectar(){
// Create connection
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "a";
    
    
        $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

    /* cambiar el conjunto de caracteres a utf8 */
    if (!mysqli_set_charset($connection, "utf8")) {
        printf("Error cargando el conjunto de caracteres utf8: %s\n", mysqli_error($connection));
    } else {
        printf("Conjunto de caracteres actual: %s\n", mysqli_character_set_name($connection));
    }
    //Por último retornas la conexión con el charset utf8 seteado. 
    return $connection;
}
    
?>