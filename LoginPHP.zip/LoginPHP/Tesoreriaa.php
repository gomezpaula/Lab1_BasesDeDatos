<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
          <!-- Eliminar aplicación doc. de clientes, - Aplicar documentos de clientes -->
        <title>TESORERIA</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/fontAwesome.css">
        <link rel="stylesheet" href="css/templatemo-style.css">

        <link rel="stylesheet" type="text/css" href="css/msdropdown/dd.css" />
        <script src="js/msdropdown/jquery-1.9.0.min.js" type="text/javascript"></script>
        <script src="js/msdropdown/jquery.dd.min.js" type="text/javascript"></script>

        <script src="js/semantic.min.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="css/semantic.min.css" />

        <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
        <script src="js/jquery-3.2.0.js" type="text/javascript"></script>
        <script src="js/ControllerContacto.js"type="text/javascript"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

        <title>JSP Page</title>
    </head>
<body>

    <style>
#submit {
font-weight: bold;
cursor: pointer;
padding: 5px;
margin: 0 10px 20px 0;
border: 1px solid #ccc;
background: #eee;
border-radius: 8px 8px 8px 8px;
}

#submit:hover {
background: #ddd;
}
    </style>


</div>




<section class="cd-hero">

    <div class="cd-slider-nav">
        <nav>
            <span class="cd-marker item-1"></span>
            <ul>

                <ul class="cd-hero-slider">

                    <li class="selected">
                        <div class="heading">

                        </div>

                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">

                                    <div class="content first-content">
                                        <style>
            #submit {
                font-weight: bold;
                cursor: pointer;
                padding: 5px;
                margin: 0 10px 20px 0;
                border: 1px solid #ccc;
                background: #eee;
                border-radius: 8px 8px 8px 8px;
            }

            #submit:hover {
                background: #ddd;
            }
                                        </style>
                                        <B>
        <div>TESORERIA</div>
   </B> 
                                       
                                        <br><br>                                      <div>
                                            <select name="OS">
                                                <!--<option selected value="0"> Tipo de Mensaje </option>-->
                                                <optgroup label="Elija una opcion"> 
                                                    <option value="1">Eliminar aplicación doc. de clientes</option> 
                                                    <option value="2">Aplicar documentos de clientes</option> 
                                                   
                                                    </div>

                                                <br>
                                                <br> 
                                                <br>    
                                                <br>

                                                <div>
                                                   <form method="post" action="subir_archivo.php" enctype="multipart/form-data"><br />
                                                        <input type="file" name="archivo" />
                                                        </center>
                                                    </form>             </div>
                                               


                                                    <br>  <br> 
                                                    <div>
                                                    <a href="" id="Cargar" class="btn btn-primary">Cargar</a>
                                                </div>
                                            <div>
        <a href="" id="eliminar" class="btn btn-primary">Eliminar Aplicación</a>
        </div>
                                                    
                                                                              
                                        </body>
                                        </html>
       
       <h1></h1>
<h3>Listado de UATP</h3>
<div id="filtros">
Filtrar información <form action="index.php" method="post"><select name="filtro"><option value="todos"></option><option value="negocio">Negocio</option><option value="cliente">Cliente</option><option value="monto">Monto</option><option value="prestador">Prestador</option></select> <button type="submit">Filtrar</button></form>
</div>
<div id="info">
    
	<?php 
        $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "a";
       $connection =mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
		$result = mysqli_query($connection,$sql);
		if(!$result )
		{
		 //	die('Ocurrio un error al obtener los valores de la base de datos: ' . mysqli_error());
		}
		echo "<center><table><th>Negocio</th><th>Inicio</th><th>Cc</th><th>Cliente</th><th>Fecha</th><th>Letra</th><th>Prefijo</th><th>Numero</th><th>Tc</th><th>Moneda</th><th>Monto</th><th>Codpre</th><th>Prestador</th>";

		while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
		{
		    echo "<tr><td>{$row['id']}</td> ".		    
                    "<td>{$row['negocio' ]} </td> ". 
                    "<td>{$row['inicio']} </td> ". 
                    "<td>{$row['cc']} </td> ".
                    "<td>{$row['cliente' ]} </td> ".
                    "<td>{$row['fecha' ]} </td> ".
                    "<td>{$row['letra' ]} </td> ".
                    "<td>{$row['prefijo' ]} </td> ".
                    "<td>{$row['numero' ]} </td> ".
                    "<td>{$row['tc' ]} </td> ".
                    "<td>{$row['moneda' ]} </td> ".
                    "<td>{$row['monto' ]} </td> ".
                    "<td>{$row['codpr' ]} </td> ".
                    "<td>{$row['prestador' ]} </td></tr>";
                }
		echo "</table></center>";
		//mysqli_close($connection);
	?>
</div>
       
    </body>
</html>
