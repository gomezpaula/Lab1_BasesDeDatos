function addContacto() {

    var nombre = $("#nom").val();
    var tel = $("#tel").val();


    $.ajax({
        url: "/WebApplication/ajax/addContacto?nombre=" + nombre + "&telefono=" + tel,
        success: success
    });

    function success(result) {
        console.log("success");
    }
//    $.ajax({
//        url: "/ajax/addContacto?nombre="+nombre+"&telefono="+tel,
//        success: function (result) {
//            console.log("success");
//        },error: function (result) {
//             console.log("error");
//        }
//    });
}


