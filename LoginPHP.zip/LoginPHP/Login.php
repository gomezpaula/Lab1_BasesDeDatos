<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
   include("checklogin.php");

   $host_db = "localhost";//donde esta alojada la bd
$user_db = "root";//user de la db
$pass_db = "";//contraseña de la db
$db_name = "tma";//nombre de la db
$tbl_name = "Usuarios";
$count = 0;
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // Usamos el nombre de usuario enviado de nuestroformulario
      
      $username = \trim($_POST ['usuario']);
      $password = \trim($_POST ['contraseña']); 
      
      $sql = "SELECT * FROM usuario WHERE usuario = '$username' and password = '$password'";
      $result = mysqli_query($conexion,$sql);
     $row = mysqli_fetch_array($result,MYSQLI_NUM);
     //printf ("%s (%s)\n",$row[0],$row[1]);
     if($estado_session == PHP_SESSION_NONE)
         
     {
         session_start();
         }
     
      $active = $row['active'];
          
          // Si el resultado combinado $myusername y $mypassword,fila de la tabla debe estar en 1 fila
		
      if($count == 1) {
         session_register("usuario");
         $_SESSION['login_user'] = $usuario;
         
         header("location: ppage.php");
      }else {
      $error = "Your Login Name or Password is invalid";
      }
   }
?>
<html>
   
   <head>
      <title>Login Page</title>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
                  label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         
         .box {
            border:#666666 solid 1px;
         }
      </style>
      
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Login</b></div>
				
            <div style = "margin:30px">
               
               <form action = "" method = "post">
                  <label>Usuario  :</label><input type = "text" name = "usuario" class = "box"/><br /><br />
                  <label>Contraseña  :</label><input type = "password" name = "contraseña" class = "box" /><br/><br />
                  <input type = "submit" value = " Submit "/><br />
               </form>
               
               <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
					
            </div>
           
				
         </div>
			
      </div>

   </body>
</html>
    </body>
</html>
