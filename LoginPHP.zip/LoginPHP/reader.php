<?php

require_once 'excelReader.php';
 
$data = new Spreadsheet_Excel_Reader();
$data->setOutputEncoding('CP1251');
$data->read('UATPtest.xlsx');
error_reporting(E_ALL ^ E_NOTICE);
echo("<table>");
for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {
	echo("<tr>");
	for ($j = 1; $j <= $data->sheets[0]['numCols']; $j++) {
		echo("<td>".$data->sheets[0]['cells'][$i][$j] ."</td>");
	}
	echo("</tr>");
 
}
echo("</table>");
