

<?php
$objReader = PHPExcel_IOFactory::createReader('Excel2007');

$objReader->setReadDataOnly(true);
$objPHPExcel = $objReader->load("UATPtest.xlsx");
$objWorksheet = $objPHPExcel->setActiveSheetIndex(1);
//objWorksheet = $objPHPExcel->getActiveSheet();

echo '<table border=1>' . "\n";
//echo '<table border=4'."n"

foreach ($objWorksheet->getRowIterator() as $row)
{
  echo '<tr>' . "\n";
  $cellIterator = $row->getCellIterator();
  $cellIterator->setIterateOnlyExistingCells(false);

  foreach ($cellIterator as $cell)
  {
    echo '<td>' . $cell->getValue() . '</td>' . "\n";
  }

  echo '</tr>' . "\n";
}

echo '</table>' . "\n";
