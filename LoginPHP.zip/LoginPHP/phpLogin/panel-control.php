<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {

} else {
   echo "Esta pagina es solo para usuarios registrados.<br>";
   echo "<br><a href='login.html'>Login</a>";
   echo "<br><a href='panel-control.php'>";
   echo "<br><br><a href='index.html'>Registrarme</a>";
   

exit;
}

$now = time();

if($now > $_SESSION['expire']) {
session_destroy();

echo "Su sesion a terminado,
<a href='login.html'>Necesita Hacer Login</a>";
exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<title>Panel de Control</title>
</head>

<body>
<div>TESORERIA</div>
   </B> 
                                       
                                        <br><br>                                      <div>
                                            <select name="OS">
                                                <!--<option selected value="0"> Tipo de Mensaje </option>-->
                                                <optgroup label="Elija una opcion"> 
                                                    <option value="1">Eliminar aplicación doc. de clientes</option> 
                                                    <option value="2">Aplicar documentos de clientes</option> 
                                                   
                                                    </div>

                                                <br>
                                                <br> 
                                                <br>    
                                                <br>

                                                <div>
                                                   <form method="post" action="subir_archivo.php" enctype="multipart/form-data"><br />
                                                        <input type="file" name="archivo" />
                                                        </center>
                                                    </form>             </div>
                                               


                                                    <br>  <br> 
                                                    <div>
                                                    <a href="" id="Cargar" class="btn btn-primary">Cargar</a>
                                                </div>
                                            
                                                                              
                                        
<a href=logout.php>Cerrar Sesion X </a>
</body>
</html>

