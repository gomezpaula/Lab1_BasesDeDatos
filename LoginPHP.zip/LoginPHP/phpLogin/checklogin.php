<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        session_start();




$host_db = "localhost";//donde esta alojada la bd
$user_db = "root";//user de la db
$pass_db = "";//contraseña de la db
$db_name = "tma";//nombre de la db
$tbl_name = "Usuarios";//nombre de la tabla en donde se encuentran los datos

$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);

 if ($conexion->connect_error) {
 die("La conexion falló: " . $conexion->connect_error);
 $resultado=$conexion->query("") or trigger_error($mysqli->error);
}

$username = filter_input(INPUT_POST,'usuario');
//$password = filter_input(INPUT_POST,'contraseña');
 
$sql = "SELECT * FROM $tbl_name WHERE nombre_usuario = '$username'";

$result = $conexion->query($sql);

//if (password_verify($password)) { 
 
//  $_SESSION['loggedin'] = true;
//  $_SESSION['username'] = $username;
//  $_SESSION['start'] = time();
//  $_SESSION['expire'] = $_SESSION['start'] + (5 * 60);


        //echo "Bienvenido! " . $_SESSION['username'];
       //echo "<br><br><a href=ppage.php>Panel de Control</a>"; 

     //} else { 
    //echo "Username o Password estan incorrectos.";

   //echo "<br><a href='login.html'>Volver a Intentarlo</a>";
  // }

 
 ?>
     
    </body>
</html>
