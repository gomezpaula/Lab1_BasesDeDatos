<?php
 
require_once 'excelReader.php';
 
$data = new Spreadsheet_Excel_Reader();
$data->setOutputEncoding('CP1251');
$data->read('UATPtest.xlsx');

//Establecemos las cabeceras para un archivo xls
header('Content-type: application/vnd.ms-excel');
		header("Content-Disposition: attachment; filename=excelenphp.xls");
		header("Pragma: no-cache");
		header("Expires: 0");
 
//Y mostramos los datos en forma de tabla
echo("<table>");
for ($i = 1; $i <= $data->sheets[0]['numRows']; $i++) {
	echo("<tr>");
	for ($j = 1; $j <= $data->sheets[0]['numCols']; $j++) {
		echo("<td>".$data->sheets[0]['cells'][$i][$j] ."</td>");
	}
	echo("</tr>");
 ini_set('error_reporting', E_ALL);
}
echo("</table>");
